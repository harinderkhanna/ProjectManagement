﻿(function () {
    var projectService = function ($http, $q, $log) {
        var cachedProjects;

        var projects = function () {
            if (cachedProjects)
                return $q.when(cachedProjects);

            return $http.get("http://localhost:52233/api/projects")

                .then(function (serviceResp) {
                    cachedProjects = serviceResp.data;
                    return serviceResp.data;
                });
        };

        var singleProject = function (id) {
            return $http.get("http://localhost:52233/api/projects/" + id)
                .then(function (serviceResp) {
                    return serviceResp.data;
                });
        };

        var insertProject = function (project) {

            return $http.post("http://localhost:52233/api/projects", project)
                .then(function (result) {
                    cachedProjects = result.data;
                    return result;
                });
        };
         


        var modifyProject = function (project) {

            return $http.put("http://localhost:52233/api/projects", project)
                .then(function (result) {
                    cachedProjects = result.data;
                    return;
                });
        };

        var deleteProject = function (project) {
            alert('delete project ' + project.project_ID);
            
            return $http.delete("http://localhost:52233/api/projects/deletebyprojectid/" + project.project_ID)
                .then(function (result) {
                    cachedProjects = result.data;
                    return result.data;
                });
        };

       

        return {
            projects: projects,
            singleProject: singleProject,
            insertProject: insertProject,
            modifyProject: modifyProject,
            deleteProject: deleteProject
             
        };
    };

    var module = angular.module("ProjectTrackingModule");

    module.factory("projectService", ["$http", "$q", "$log", projectService]);
}());
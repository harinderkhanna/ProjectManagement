﻿(function () {

    var cachedUsers;
    var UserService = function ($http, $q, $log) {

        var users = function () {

          
            return $http.get("http://localhost:52233/api/users")
                        .then(function (serviceResp) {
                            return serviceResp.data;
                        });
        };

        var insertUser = function (user) {
            return $http.post("http://localhost:52233/api/users", user)
            .then(function (result) {
                cachedUsers = result.data;

                return result;
            });
        };
        var modifyUser = function (user) {
            return $http.put("http://localhost:52233/api/users", user)
            .then(function (result) {
                cachedUsers = result.data;
                return;
            });
        };

        var deleteUser = function (user) {

            return $http.delete("http://localhost:52233/api/users/deletebyuserid/" + user.employee_ID)
            .then(function (result) {

                cachedUsers = result.data;
                return result.data;
            });
        };
        var searchUser = function (name) {

            return $http.get("http://localhost:52233/api/users/byusername/" + name)
            .then(function (serviceResp) {
                return serviceResp.data;
            });
        };
        var singleuser = function (id) {

            return $http.get("http://localhost:52233/api/users/" + id)
                        .then(function (serviceResp) {
                            return serviceResp.data;
                        });
        };
        return {
            users: users,
            insertUser: insertUser,
            searchUser: searchUser,
            singleuser: singleuser,
            modifyUser: modifyUser,
            deleteUser: deleteUser
        };
    };
    var module = angular.module("ProjectTrackingModule");
    module.factory("UserService", ["$http", "$q", "$log", UserService]);
}());
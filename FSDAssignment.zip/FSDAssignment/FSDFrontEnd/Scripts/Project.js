﻿var projectPage = {};
$(function () {
     
   
    $("#txtprojectenddate").on("change leave", function () {
        if (projectPage.validationFunctions.isNullValue(projectPage.validationFunctions.getStartDateSelectedValue())
            && projectPage.validationFunctions.isNullValue(projectPage.validationFunctions.getEndDateSelectedValue())) {
            alert("The values can't be null!.");
        } else {
            projectPage.validationFunctions.isEndDateGreaterStart();
        }
    });
});

projectPage.validationFunctions = (function () {
    
    return {
        getStartDateSelectedValue: function () {
             
            return $("#txtprojectstartdate").val();
        },
        getEndDateSelectedValue: function () {
            return $("#txtprojectenddate").val();
        },
        isNullValue: function (selVal) {
            if (selVal.trim() == "") {
                return true;
            }
            else {
                return false;
            }
        },
        isNullValueWithUIElements: function () {
            if (projectPage.validationFunctions.isNullValue(projectPage.validationFunctions.getStartDateSelectedValue())
                && projectPage.validationFunctions.isNullValue(projectPage.validationFunctions.getEndDateSelectedValue())) {
                alert("The values can't be null!.");
            }
        },
        isEndDateGreaterStart: function () {
            var startDate = new Date(projectPage.validationFunctions.getStartDateSelectedValue());
            var endDate = new Date(projectPage.validationFunctions.getEndDateSelectedValue());
            if (startDate < endDate) {
                return true;
            }
            else {
                alert("End date must be greater than start date!.")
                return false;
            }
        }
    }
}(jQuery));
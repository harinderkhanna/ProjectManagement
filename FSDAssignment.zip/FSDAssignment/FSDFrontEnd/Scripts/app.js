﻿var app = angular.module('ProjectTrackingModule', ['ngRoute', 'ui.bootstrap']);
 
app.config(function ($routeProvider) {
    $routeProvider
        .when("/Home", {
            templateUrl: "/Home.html",
            controller:"HomeController"
        })
        .when("/Projects", {
        templateUrl: "ProjectManagement/ProjectDetails.html",
        controller: "ProjectsController"
        })
        .when("/NewProject", {
            templateUrl: "ProjectManagement/ProjectInsert.html",
            controller: "ProjectsController"
        })
        .when("/ModifyProject/:projectID", {
            templateUrl: "ProjectManagement/ProjectModify.html",
            controller: "ProjectsController"
        })
        .when("/UserStories", {
            templateUrl: "UserStories/UserStoryDetails.html",
            controller: "UserStoriesController"
        })
        .when("/NewUserStory", {
            templateUrl: "UserStories/UserStoryInsert.html",
            controller: "UserStoriesController"
        })
        .when("/ModifyUserStory/:userStoryID", {
            templateUrl: "UserStories/UserStoryUpdate.html",
            controller: "UserStoriesController"
        })
        .when("/Users", {
            templateUrl: "Users/EmployeeDetails.html",
            controller: "UsersController"
        })
        .when("/NewUser", {
            templateUrl: "Users/UserInsert.html",
            controller: "UsersController"
        })
        .when("/AllUsers", {
            templateUrl: "Users/UserSearch.html",
            controller: "UsersController"
        })
        .when("/ModifyUser/:employee_ID", {
            templateUrl: "Users/UserModify.html",
            controller: "UsersController"
        })
        .when("/Tasks", {
            templateUrl: "Tasks/ProjectTaskDetails.html",
            controller: "ProjectTasksController"
        })
        .when("/NewTask", {
            templateUrl: "Tasks/ProjectTaskInsert.html",
            controller: "ProjectTasksController"
        })
        .when("/ModifyTask/:projectTaskID", {
            templateUrl: "Tasks/ProjectTaskModify.html",
            controller: "ProjectTasksController"
        })
    .otherwise({redirectTo:"/Home"})
});
 

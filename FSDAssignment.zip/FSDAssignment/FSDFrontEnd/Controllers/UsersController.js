﻿(function () {
   
    var UsersController = function ($scope, UserService, $routeParams, $log, $location) {
        
        var users = function (data) {
            $scope.Users = data;
        };
       
        var singleuser = function (data) {
            
            $scope.existinguser = data;
 
        };

        $scope.init = function () {
           
            UserService.singleuser($routeParams.employee_ID)
                .then(singleuser, errorDetails);
        };

         

        $scope.searchUser = function (name) {
          
            UserService.searchUser(name)
            .then(users, errorDetails);
           
        };
        $scope.AllUsers = function (name) {
        
            UserService.searchUser(name)
                .then(users, errorDetails);

        };
        $scope.insertUser = function (user) {
          
            UserService.insertUser(user)
                .then(function () {
                    refresh();
                    $location.path("/NewUser");
                }, errorDetails);
        };

        $scope.modifyuser = function (modifieduser) {
            
            UserService.modifyUser(modifieduser)
                 .then(function () {
                     refresh();
                     $location.path("/NewUser");
                 }, errorDetails);
                 
        };

        $scope.deleteuser = function (deleteduser) {
         
            UserService.deleteUser(deleteduser)
                 .then(function () {
                     refresh();
                     $location.path("/NewUser");
                 }, errorDetails);

        };

        var errorDetails = function (serviceResp) {
            $scope.Error="Something went wrong ??";
        };

        var refresh = function () {
                       UserService.users()
                .then(users, errorDetails);
        };

        refresh();
        
        UserService.users().then(users, errorDetails);
        $scope.UserName = null;
    };
    app.controller("UsersController", ["$scope", "UserService","$routeParams", "$log","$location", UsersController]);
}());
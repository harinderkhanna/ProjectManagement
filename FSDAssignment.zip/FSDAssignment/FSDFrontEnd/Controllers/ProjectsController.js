﻿(function () {
 
   
    var ProjectsController = function ($scope, projectService,$log,$routeParams,$location) {
        var projects = function (data) {
            $scope.Projects = data;
            $log.info(data);
        };

        function convertDateToBindable(date) {
            var dateObj = new Date(date);

            return dateObj.getFullYear() + "-" + getTwoDigitString(dateObj.getMonth() + 1) + "-" + getTwoDigitString(dateObj.getDate());
        }

        function getTwoDigitString(number) {
            if (number.toString().length === 1)
                return "0" + number;
            return number;
        }
        $scope.openDlg = function () {
           
            var dlgElem = angular.element("#modalDlg");
            if (dlgElem) {
              
                $('#modalDlg').modal('show');
            }
           

      
        };

        $scope.myfunction = function (data) {
           
            $('[name="managerName"]').val(data.employee_ID);
            $('#modalDlg').modal('hide');
        };
        
        var singleProject = function (data) {
      
            $scope.existingProject = data;
           
            
            $scope.existingProject = data;

            $scope.existingProject.start_Date = convertDateToBindable($scope.existingProject.start_Date);
            $scope.existingProject.end_Date = convertDateToBindable($scope.existingProject.end_Date);
 
        };

        $scope.init = function () {
         
            projectService.singleProject($routeParams.projectID)
                .then(singleProject, errorDetails);
        };

        var project = {
            projectID: null,
            projectName: null,
            startDate: null,
            endDate: null,
            priority:null,
            managerName: null
        };

        $scope.project = project;
        
        var errorDetails = function (serviceResp) {
            $scope.Error = "Something went wrong ??";
        };

        $scope.insertProject=function (project) {
            projectService.insertProject(project)
                .then(function (data) {
                    refresh();
                    $location.path("/NewProject");
                });
        };

        $scope.modifyProject = function (existingProject) {
           
            projectService.modifyProject(existingProject)
                .then(function () {
                    refresh();
                    $location.path("/NewProject");
                }, errorDetails);
             
        };

        $scope.deleteProject = function (project) {
           
            projectService.deleteProject(project)
                .then(projects, errorDetails);
        };

        

        var refresh = function () {
            projectService.projects()
                .then(projects, errorDetails);
        };

        refresh();
        
    };
    app.controller("ProjectsController", ["$scope", "projectService", "$log", "$routeParams", "$location", ProjectsController]);
}());
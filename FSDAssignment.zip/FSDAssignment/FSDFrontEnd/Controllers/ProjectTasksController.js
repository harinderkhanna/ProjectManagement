﻿(function () {
    var ProjectTasksController = function ($scope, $location, projectTasksService) {
        var userStories = function (data) {
            $scope.Stories = data;
        };
        var errorDetails = function (serviceResp) {
            $scope.Error = "Something went wrong!!";
        };

        
        var projectTasks = function (data) {
             
            $scope.Tasks = data;
        };
        var errorDetails = function (serviceResp) {
            $scope.Error = "Something went wrong ??";
        };

        $scope.assignTask = function () {
            $scope.task.userStoryID = $scope.userStorySelected.userStoryID;

            projectTasksService.addProjectTask($scope.task).then(function () {
                $location.path("/Tasks");
            });
        };
        $scope.openDlg = function () {

            var dlgElem = angular.element("#modalDlg");
            if (dlgElem) {

                $('#modalDlg').modal('show');
            }
         };

        $scope.openProjectDlg = function () {
          
            var dlgElem = angular.element("#projectmodalDlg");
            if (dlgElem) {

                $('#projectmodalDlg').modal('show');
            }
        };
        $scope.myfunction = function (data) {

            $('[name="managerName"]').val(data.employee_ID);
            $('#modalDlg').modal('hide');
        };
        projectTasksService.projectTasks().then(projectTasks, errorDetails);
      
    };
    app.controller("ProjectTasksController", ["$scope", "$location", "projectTasksService", ProjectTasksController]);
}());
﻿using System;
using NUnit.Framework;
using FSDAPI.Controllers;
using FSDAPI.Models;
namespace UnitTestProject1
{
    [TestFixture]
    public class ControllerTests
    {
        ProjectsController projectsController;
        ProjectsRepository projectrepository;

        int count;
        int projectid;

        [SetUp]
        public void Setup()
        {

            projectrepository = new ProjectsRepository();

            projectsController = new ProjectsController(projectrepository);

            count = projectsController.Get().Count;

            projectid = projectsController.Get(1).Project_ID;
        }

        [Test]
        public void GetAllProjects()
        {
            Assert.IsTrue(count > 0);
        }

        [Test]
        public void GetProject()
        {
            Assert.IsTrue(projectid.Equals(1));
        }
    }
}

﻿using FSDAssignment;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FSDAPI.Models
{
    public class ProjectsRepository : IDisposable
    {
        private FSDDBEntities1 dataContext;

        public ProjectsRepository()
        {
            dataContext = new FSDDBEntities1();
        }

        public List<Project> GetAllProjects()
        {
            
            var query = from project in dataContext.Projects
                        select project;
            return query.ToList();
        }
        public Project GetProject(int ProjectID)
        {
            var query = from project in dataContext.Projects
                        where project.Project_ID==ProjectID
                        select project;
            return query.SingleOrDefault();
        }
        public List<Project> GetProjectByName(string projectName)
        {
            var query = from project in dataContext.Projects
                        where project.Project_Name.Contains(projectName)
                        select project;
            return query.ToList();
        }
        public List<Project> InsertProject(Project p)
        {
            dataContext.Projects.Add(p);
            dataContext.SaveChanges();
            return GetAllProjects();
        }
        public List<Project> UpdateProject(Project p)
        {
            var proj = (from project in dataContext.Projects
                       where project.Project_ID == p.Project_ID
                       select project).SingleOrDefault();
            proj.Project_Name = p.Project_Name;
            proj.Start_Date = p.Start_Date;
            proj.End_Date = p.End_Date;
            proj.Priority = p.Priority;
            dataContext.SaveChanges();
            return GetAllProjects();
        }
        public List<Project> DeleteProject(int projectId)
        {
            dataContext.Configuration.LazyLoadingEnabled = false;
            var proj = (from project in dataContext.Projects
                        where project.Project_ID == projectId
                        select project).SingleOrDefault();
            dataContext.Projects.Remove(proj);
            dataContext.SaveChanges();
            return GetAllProjects();
        }

        public void Dispose()
        {
            dataContext.Dispose();
        }
    }
}
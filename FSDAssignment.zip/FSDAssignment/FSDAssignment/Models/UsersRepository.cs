﻿using FSDAssignment;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FSDAPI.Models
{
    public class UserRepository
    {
        private static FSDDBEntities1 dataContext = new FSDDBEntities1();
        
        public static List<User> GetAllUsers()
        {
            var query = from user in dataContext.Users
                        select user;
            return query.ToList();
        }

        public static List<User> SearchUserByName(string username)
        {
            var query = from user in dataContext.Users
                        where user.First_Name.Contains(username)
                        select user;
            return query.ToList();
        }
        public static User GetUser(int userid)
        {
            var query = from user in dataContext.Users
                        where user.Employee_ID == userid
                        select user;
            return query.SingleOrDefault();
        }
        public static List<User> InsertUser(User user)
        {
            dataContext.Users.Add(user);
            dataContext.SaveChanges();
            return GetAllUsers();
        }
        public static List<User> UpdateUser(User user)
        {
            var usr = (from tmpuser in dataContext.Users
                       where tmpuser.Employee_ID == user.Employee_ID
                       select tmpuser).SingleOrDefault();
            usr.First_Name = user.First_Name;
            usr.Last_Name = user.Last_Name;
          
            dataContext.SaveChanges();
            return GetAllUsers();
        }
        public static List<User> DeleteUser(int employeeid)
        {
            
            dataContext.Configuration.LazyLoadingEnabled = false;
             
            var usr = (from tmpuser in dataContext.Users
                       where tmpuser.Employee_ID == employeeid
                       select tmpuser).SingleOrDefault();
            dataContext.Users.Remove(usr);
            dataContext.SaveChanges();
            return GetAllUsers();
        }
    }
}
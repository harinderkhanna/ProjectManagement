﻿using FSDAssignment;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FSDAPI.Models
{
    public class ProjectTasksRepository
    {
        private static  FSDDBEntities1 dataContext = new FSDDBEntities1();
        public static List<Task> GetAllProjectTasks()
        {
            var query = from projTasks in dataContext.Tasks
                        select projTasks;
            return query.ToList();
        }
        public static Task GetProjectTask(int ProjectTaskID)
        {
            var query = (from projTasks in dataContext.Tasks
                         where projTasks.Task_ID==ProjectTaskID
                        select projTasks).SingleOrDefault();
            return query;
        }
        public static List<Task> InsertProjectTask(Task PT)
        {
            dataContext.Tasks.Add(PT);
            dataContext.SaveChanges();
            return GetAllProjectTasks();
        }
        public static List<Task> UpdateProjectTask(Task PT)
        {
            var projectTask = (from projTasks in dataContext.Tasks
                               where projTasks.Task_ID == PT.Task_ID
                        select projTasks).SingleOrDefault();
            
            projectTask.Start_Date = PT.Start_Date;
            projectTask.End_Date = PT.End_Date;
            projectTask.Status = PT.Status;
            projectTask.Priority = PT.Priority;
            dataContext.SaveChanges();
            return GetAllProjectTasks();
        }
        public static List<Task> DeleteProjectTask(Task PT)
        {
            var projectTask = (from projTasks in dataContext.Tasks
                               where projTasks.Task_ID == PT.Task_ID
                               select projTasks).SingleOrDefault();
            dataContext.Tasks.Remove(projectTask);
            dataContext.SaveChanges();
            return GetAllProjectTasks();
        }
    }
}
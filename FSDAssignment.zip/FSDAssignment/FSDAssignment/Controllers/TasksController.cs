﻿using FSDAPI.Models;
using FSDAssignment;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Cors;
//using System.Web.Http.Cors;

namespace FSDAPI.Controllers
{
    [EnableCors(origins: "http://localhost:52951", headers: "*", methods: "*")]
    public class ProjectTasksController : ApiController
    {
        // GET api/projecttasks
        [Route("api/projecttasks")]
        public IEnumerable<Task> Get()
        {
            return ProjectTasksRepository.GetAllProjectTasks();
        }

        // GET api/projecttasks/5
        [Route("api/projecttasks/{id?}")]
        public Task Get(int id)
        {
            return ProjectTasksRepository.GetProjectTask(id);
        }

        [Route("api/projecttasks")]
        public IEnumerable<Task> Post(Task pt)
        {
            return ProjectTasksRepository.InsertProjectTask(pt);
        }

        [Route("api/projecttasks")]
        public IEnumerable<Task> Put(Task pt)
        {
            return ProjectTasksRepository.UpdateProjectTask(pt);
        }

        [Route("api/projecttasks")]
        public IEnumerable<Task> Delete(Task pt)
        {
            return ProjectTasksRepository.DeleteProjectTask(pt);
        }
    }
}

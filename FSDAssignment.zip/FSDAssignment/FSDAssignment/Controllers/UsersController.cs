﻿using FSDAPI.Models;
using FSDAssignment;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Cors;

namespace FSDAPI.Controllers
{
    [EnableCors(origins: "http://localhost:52951", headers: "*", methods: "*")]
    public class UsersController : ApiController
    {
        // GET api/users
        [Route("api/users")]
        public HttpResponseMessage Get()
        {
            var users = UserRepository.GetAllUsers();
            HttpResponseMessage response = Request.CreateResponse(HttpStatusCode.OK, users);
            return response;
        }
        // GET api/users/5
        [Route("api/users/{id?}")]
        public HttpResponseMessage Get(int id)
        {
            var user = UserRepository.GetUser(id);
            HttpResponseMessage response = Request.CreateResponse(HttpStatusCode.OK, user);
            return response;
        }
        [Route("api/users/byusername/{name}")]
        public HttpResponseMessage GetByUserName(string name)
        {
            var user = UserRepository.SearchUserByName(name);
            HttpResponseMessage response = Request.CreateResponse(HttpStatusCode.OK, user);
            return response;
        }

        [Route("api/users")]
        public HttpResponseMessage Post(User user)
        {
            var updateresult = UserRepository.InsertUser(user);
            HttpResponseMessage response = Request.CreateResponse(HttpStatusCode.OK, updateresult);
            return response;
        }

        [Route("api/users")]
        public HttpResponseMessage Put(User user)
        {
            var updateresult = UserRepository.UpdateUser(user);
            HttpResponseMessage response = Request.CreateResponse(HttpStatusCode.OK, updateresult);
            return response;
        }


        [Route("api/users/deletebyuserid/{id}")]

        public HttpResponseMessage DeleteByUserID(int id)
        {

            var updateresult = UserRepository.DeleteUser(id);
            HttpResponseMessage response = Request.CreateResponse(HttpStatusCode.OK);
            return response;
        }
    }
}

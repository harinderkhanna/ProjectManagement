﻿using FSDAPI.Models;
using FSDAssignment;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Cors;

namespace FSDAPI.Controllers
{
    [EnableCors(origins: "http://localhost:52951", headers: "*", methods: "*")]
    public class ProjectsController : ApiController
    {
        ProjectsRepository repository;

        public ProjectsController()
        {
            repository = new ProjectsRepository();
        }

        public ProjectsController(ProjectsRepository _repository)
        {
            repository = _repository;
        }

        // GET api/projects
        [Route("api/projects")]
        public List<Project> Get()
        {
            return repository.GetAllProjects();
        }

        // GET api/projects/5
        [Route("api/projects/{id?}")]
        public Project Get(int id)
        {
            return repository.GetProject(id);
        }

        [Route("api/projects/{name:alpha}")]
        public IEnumerable<Project> Get(string name)
        {
            return repository.GetProjectByName(name);
        }

        [Route("api/projects")]
        public IEnumerable<Project> Post(Project p)
        {
            return repository.InsertProject(p);
        }

        [Route("api/projects")]
        public HttpResponseMessage Put([FromBody]Project p)
        {
            var updateresult = repository.UpdateProject(p);
            HttpResponseMessage response = Request.CreateResponse(HttpStatusCode.OK, updateresult);
            return response;
            
        }

        [Route("api/projects/{id}")]
        [HttpDelete]
        public HttpResponseMessage Delete(int id)
        {
           
            var updateresult = repository.DeleteProject(id);
            HttpResponseMessage response = Request.CreateResponse(HttpStatusCode.OK,updateresult);
            return response;
        }

        [Route("api/projects/deletebyprojectid/{id}")]
        public HttpResponseMessage DeleteByProjectID(int id)
        {

            var updateresult = repository.DeleteProject(id);
            HttpResponseMessage response = Request.CreateResponse(HttpStatusCode.OK, updateresult);
            return response;
        }
    }
}

﻿describe("Validations for Project Page", function () {
    var projectPage;
    beforeEach(function () {
     
        projectPage = window.projectPage.validationFunctions;
        window.alert = jasmine.createSpy("alert").and.callFake(function () { });
    });

    it("Check for null values", function () {
      
        var retVal = projectPage.isNullValue("");
        expect(retVal).toBeTruthy();
    });

    

});